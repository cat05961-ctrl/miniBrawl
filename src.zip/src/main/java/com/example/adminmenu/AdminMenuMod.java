package com.example.adminmenu;

// Импорты Forge 1.20.4
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod("admin_menu")
public class AdminMenuMod {

    public AdminMenuMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onKeyPress(InputEvent.Key event) {
        if (event.getKey() == GLFW.GLFW_KEY_K && event.getAction() == GLFW.GLFW_PRESS) {
            Minecraft.getInstance().setScreen(new AdminScreen());
        }
    }

    public static class AdminScreen extends Screen {
        protected AdminScreen() {
            super(Component.literal("Admin Menu"));
        }

        @Override
        protected void init() {
            int buttonWidth = 200;
            int x = this.width / 2 - buttonWidth / 2;

            this.addRenderableWidget(Button.builder(Component.literal("§cВЫКЛЮЧИТЬ СЕРВЕР"), (btn) -> {
                Minecraft.getInstance().player.connection.sendUnsignedCommand("stop");
            }).bounds(x, 40, buttonWidth, 20).build());

            this.addRenderableWidget(Button.builder(Component.literal("§6Кикнуть всех"), (btn) -> {
                Minecraft.getInstance().player.connection.sendUnsignedCommand(
                    "kick @a[name=!" + Minecraft.getInstance().player.getName().getString() + "] Очистка сервера"
                );
            }).bounds(x, 70, buttonWidth, 20).build());

            this.addRenderableWidget(Button.builder(Component.literal("Смена режима (GM 1/0)"), (btn) -> {
                String cmd = Minecraft.getInstance().player.isCreative()
                        ? "gamemode survival"
                        : "gamemode creative";
                Minecraft.getInstance().player.connection.sendUnsignedCommand(cmd);
            }).bounds(x, 100, buttonWidth, 20).build());
        }

        @Override
        public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
            this.renderBackground(guiGraphics, mouseX, mouseY, partialTick);
            guiGraphics.drawCenteredString(this.font, this.title, this.width / 2, 15, 0xFFFFFF);
            super.render(guiGraphics, mouseX, mouseY, partialTick);
        }
    }
}
