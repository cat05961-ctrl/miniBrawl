export type InstanceStatus = 'provisioning' | 'running' | 'stopping' | 'stopped' | 'error';

export interface Instance {
  id: string;
  name: string;
  status: InstanceStatus;
  ip?: string;
  cpu: number;
  ram: number;
  storage: number;
  version?: string;
  port?: number;
  type?: 'cloud' | 'local';
  plugins?: string[];
  createdAt: any;
  updatedAt: any;
  ownerId: string;
}

export interface ServerLog {
  id: string;
  instanceId: string;
  message: string;
  timestamp: any;
  level: 'info' | 'warn' | 'error';
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}
