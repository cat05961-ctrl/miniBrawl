import { 
  collection, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  getDocs,
  doc, 
  serverTimestamp, 
  onSnapshot, 
  query, 
  where, 
  orderBy,
  limit
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { Instance, InstanceStatus, OperationType, FirestoreErrorInfo, ServerLog } from '../types/cloud';
import { generateIp } from '../lib/utils';

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export const serverService = {
  getInstances: (userId: string, callback: (instances: Instance[]) => void) => {
    const path = 'instances';
    const q = query(collection(db, path), where('ownerId', '==', userId));
    
    return onSnapshot(q, (snapshot) => {
      const instances = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Instance));
      // Manual sort to avoid index requirement
      instances.sort((a, b) => {
        const timeA = a.createdAt?.toMillis?.() || 0;
        const timeB = b.createdAt?.toMillis?.() || 0;
        return timeB - timeA;
      });
      callback(instances);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  },

  createInstance: async (name: string, cpu: number, ram: number, storage: number, version: string, type: 'cloud' | 'local' = 'cloud') => {
    if (!auth.currentUser) throw new Error('You must be logged in to create a server');
    const path = 'instances';
    try {
      const port = type === 'cloud' ? Math.floor(Math.random() * 1000) + 25000 : 25565;
      
      const payload = {
        name,
        cpu,
        ram,
        storage,
        version,
        port,
        type,
        plugins: [],
        status: 'provisioning' as InstanceStatus,
        ownerId: auth.currentUser.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const result = await addDoc(collection(db, path), payload);

      // Deployment Logic: Instant status update and network configuration
      const deploymentIp = type === 'cloud' ? generateIp() : '127.0.0.1';
      
      try {
        await updateDoc(doc(db, path, result.id), {
          status: 'running',
          ip: deploymentIp,
          updatedAt: serverTimestamp()
        });
        
        await serverService.addLog(result.id, `FRA-Node Connection Established. Resources verified.`, 'info');
        await serverService.addLog(result.id, `Starting Paper ${version} node on ${deploymentIp}:${port}`, 'info');
        await serverService.addLog(result.id, 'Deployment Complete. Node is operational.', 'info');
      } catch (err) {
        console.error('Finalizing provision failed:', err);
      }

      return result.id;
    } catch (error: any) {
      console.error('Provisioning Error:', error);
      throw new Error(error?.message || 'Host connection refused. Try refreshing the page.');
    }
  },

  addPlugin: async (instanceId: string, pluginName: string, currentPlugins: string[]) => {
    if (currentPlugins.includes(pluginName)) return;
    const path = `instances/${instanceId}`;
    try {
      await updateDoc(doc(db, 'instances', instanceId), {
        plugins: [...currentPlugins, pluginName],
        updatedAt: serverTimestamp()
      });
      await serverService.addLog(instanceId, `Plugin ${pluginName} successfully downloaded and installed.`, 'info');
      await serverService.addLog(instanceId, `RESTART REQUIRED for changes to take effect.`, 'warn');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  removePlugin: async (instanceId: string, pluginName: string, currentPlugins: string[]) => {
    const path = `instances/${instanceId}`;
    try {
      await updateDoc(doc(db, 'instances', instanceId), {
        plugins: currentPlugins.filter(p => p !== pluginName),
        updatedAt: serverTimestamp()
      });
      await serverService.addLog(instanceId, `Plugin ${pluginName} uninstalled.`, 'info');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  startServer: async (id: string) => {
    const path = `instances/${id}`;
    try {
      await updateDoc(doc(db, 'instances', id), {
        status: 'running',
        updatedAt: serverTimestamp()
      });
      await serverService.addLog(id, 'System Power-On Sequence Initiated.', 'info');
      await serverService.addLog(id, 'Node Status: Operational.', 'info');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  stopServer: async (id: string) => {
    const path = `instances/${id}`;
    try {
      await updateDoc(doc(db, 'instances', id), {
        status: 'stopped',
        updatedAt: serverTimestamp()
      });
      await serverService.addLog(id, 'System Shutdown Sequence Initiated.', 'info');
      await serverService.addLog(id, 'Node Status: Offline.', 'warn');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  deleteServer: async (id: string) => {
    const path = `instances/${id}`;
    try {
      await deleteDoc(doc(db, 'instances', id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  addLog: async (instanceId: string, message: string, level: ServerLog['level'] = 'info') => {
    const path = `instances/${instanceId}/logs`;
    try {
      await addDoc(collection(db, 'instances', instanceId, 'logs'), {
        instanceId,
        message,
        level,
        timestamp: serverTimestamp()
      });
    } catch (error) {
       // Silently fail or log for logs to avoid breaking UX
       console.error('Log error', error);
    }
  },

  getLogs: (instanceId: string, callback: (logs: ServerLog[]) => void) => {
    const path = `instances/${instanceId}/logs`;
    const q = query(
      collection(db, 'instances', instanceId, 'logs'), 
      limit(50)
    );
    
    return onSnapshot(q, (snapshot) => {
      const logs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as ServerLog));
      // Sort manually to avoid index requirement
      logs.sort((a, b) => {
        const timeA = a.timestamp?.toMillis?.() || 0;
        const timeB = b.timestamp?.toMillis?.() || 0;
        return timeA - timeB; // Logs ascending for terminal feel
      });
      callback(logs);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
  }
};
