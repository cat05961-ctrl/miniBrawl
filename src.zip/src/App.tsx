import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Gamepad2, 
  Terminal, 
  Activity, 
  Plus, 
  Power, 
  Settings, 
  Trash2, 
  Cpu, 
  HardDrive, 
  Database,
  Search,
  LayoutDashboard,
  Shield,
  Cloud,
  LogOut,
  ChevronRight,
  Loader2,
  Send,
  Globe,
  Zap,
  ShieldCheck,
  Server
} from 'lucide-react';
import { auth, signIn, logout } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { cn } from './lib/utils';
import { Instance, ServerLog } from './types/cloud';
import { serverService } from './services/serverService';
import { format } from 'date-fns';

// --- Components ---

const Button = ({ 
  children, 
  className, 
  variant = 'primary', 
  size = 'md',
  ...props 
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'danger' | 'ghost', size?: 'sm' | 'md' | 'lg' }) => {
  const variants = {
    primary: 'bg-blue-600 text-white hover:bg-blue-500 border-none shadow-lg shadow-blue-500/20',
    secondary: 'bg-slate-800 text-white border-slate-700 hover:bg-slate-700',
    danger: 'bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white border-red-500/20',
    ghost: 'bg-transparent text-slate-400 hover:text-white border-none'
  };
  
  const sizes = {
    sm: 'px-2 py-1 text-[10px] rounded-lg',
    md: 'px-4 py-2 text-sm rounded-xl',
    lg: 'px-6 py-3 text-base font-bold rounded-xl'
  };

  return (
    <button 
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-md transition-all duration-200 border cursor-pointer active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed font-sans font-medium tracking-tight',
        variants[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
};

const Card = ({ children, className, title, icon: Icon }: { children: React.ReactNode, className?: string, title?: string, icon?: any }) => (
  <div className={cn('bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col', className)}>
    {title && (
      <div className="px-5 py-3 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {Icon && <Icon className="w-4 h-4 text-blue-500" />}
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">{title}</span>
        </div>
        <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono tracking-tighter">LIVE</span>
      </div>
    )}
    <div className="p-5 flex-1">
      {children}
    </div>
  </div>
);

const Badge = ({ status }: { status: Instance['status'] }) => {
  const styles = {
    provisioning: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    running: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    stopping: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    stopped: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
    error: 'bg-red-500/10 text-red-400 border-red-500/20',
  };
  return (
    <div className={cn('flex items-center px-2 py-1 rounded-full border', styles[status])}>
      <div className={cn('w-1.5 h-1.5 rounded-full mr-2', status === 'running' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]' : 'bg-current')} />
      <span className="text-[10px] font-bold uppercase tracking-widest">
        {status}
      </span>
    </div>
  );
};

const LogPanel = ({ instanceId, onClose }: { instanceId: string, onClose: () => void }) => {
  const [logs, setLogs] = React.useState<ServerLog[]>([]);
  const [command, setCommand] = React.useState('');
  const [executing, setExecuting] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const unsub = serverService.getLogs(instanceId, setLogs);
    return () => unsub();
  }, [instanceId]);

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const execCommand = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!command || executing) return;
    
    setExecuting(true);
    const cmd = command;
    setCommand('');
    
    try {
      await serverService.addLog(instanceId, `cloud@engine:~$ ${cmd}`, 'info');
      const response = await fetch('/api/terminal/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, instanceId })
      });
      const data = await response.json();
      await serverService.addLog(instanceId, data.output, 'info');
    } catch (e) {
      console.error(e);
      await serverService.addLog(instanceId, 'Connection Lost: Terminal bridge offline.', 'error');
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col h-[600px]"
      >
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
          <div className="flex items-center gap-3">
            <Terminal className="w-5 h-5 text-blue-500" />
            <h3 className="font-sans text-sm font-semibold text-white tracking-tight">Interactive Remote Terminal</h3>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>Close Session</Button>
        </div>
        <div 
          ref={scrollRef}
          className="flex-1 p-4 font-mono text-[11px] overflow-y-auto space-y-1 bg-slate-950"
        >
          {logs.map((log) => (
            <div key={log.id} className="flex gap-4 group">
              <span className="text-slate-600 shrink-0">
                [{log.timestamp ? format(log.timestamp.toDate(), 'HH:mm:ss') : '--:--:--'}]
              </span>
              <span className={cn(
                'shrink-0 font-bold',
                log.level === 'error' ? 'text-red-500' : 
                log.level === 'warn' ? 'text-orange-500' : 'text-blue-500'
              )}>
                [{log.level.toUpperCase()}]
              </span>
              <span className="text-slate-300 group-hover:text-white transition-colors">{log.message}</span>
            </div>
          ))}
          {executing && (
            <div className="flex gap-4 mt-2">
              <span className="text-slate-600">[WAIT]</span>
              <span className="text-blue-500 animate-pulse">Running process...</span>
            </div>
          )}
        </div>
        
        <form onSubmit={execCommand} className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-3">
           <span className="text-emerald-500 font-mono text-xs font-bold">$</span>
           <input 
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              placeholder="Enter command (ls, uptime, whoami...)"
              className="flex-1 bg-transparent border-none focus:outline-none text-white font-mono text-xs placeholder:text-slate-700"
              autoFocus
              disabled={executing}
           />
           <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
        </form>
      </motion.div>
    </div>
  );
};

const PluginModal = ({ isOpen, onClose, instance }: { isOpen: boolean, onClose: () => void, instance: Instance }) => {
  const [loading, setLoading] = React.useState(false);
  const availablePlugins = [
    { id: 'essentials', name: 'EssentialsX', desc: 'Core server capabilities' },
    { id: 'luckperms', name: 'LuckPerms', desc: 'Advanced permissions plugin' },
    { id: 'worldedit', name: 'WorldEdit', desc: 'In-game map editor' },
    { id: 'dynmap', name: 'Dynmap', desc: 'Google Maps-like live map' },
    { id: 'vault', name: 'Vault', desc: 'Economy & permissions API' },
    { id: 'clearlag', name: 'ClearLag', desc: 'Optimize server performance' }
  ];

  const handleInstall = async (name: string) => {
    setLoading(true);
    try {
      await serverService.addPlugin(instance.id, name, instance.plugins || []);
    } finally {
      setLoading(false);
    }
  };

  const handleRemove = async (name: string) => {
    setLoading(true);
    try {
      await serverService.removePlugin(instance.id, name, instance.plugins || []);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden p-8 shadow-2xl"
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-semibold text-white tracking-tight flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Plus className="w-6 h-6 text-white" />
            </div>
            Manage Plugins
          </h2>
          <Button variant="ghost" size="sm" onClick={onClose}>Close</Button>
        </div>

        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
          {availablePlugins.map((plugin) => {
            const isInstalled = instance.plugins?.includes(plugin.name);
            return (
              <div key={plugin.id} className="flex items-center justify-between p-4 bg-slate-800/50 border border-slate-700 rounded-xl hover:border-blue-500/30 transition-all">
                <div>
                  <div className="text-sm font-bold text-white uppercase tracking-tight">{plugin.name}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{plugin.desc}</div>
                </div>
                {isInstalled ? (
                  <Button size="sm" variant="danger" onClick={() => handleRemove(plugin.name)} disabled={loading}>Remove</Button>
                ) : (
                  <Button size="sm" onClick={() => handleInstall(plugin.name)} disabled={loading}>Install</Button>
                )}
              </div>
            );
          })}
        </div>
      </motion.div>
    </div>
  );
};

const ProvisionModal = ({ isOpen, onClose, currentCount }: { isOpen: boolean, onClose: () => void, currentCount: number }) => {
  const [loading, setLoading] = React.useState(false);
  const [name, setName] = React.useState('');
  const [mode, setMode] = React.useState<'cloud' | 'local'>('cloud');
  const [version, setVersion] = React.useState('1.20.4');
  const [cores, setCores] = React.useState(4);
  const [ram, setRam] = React.useState(12);
  
  const create = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || loading) return;
    if (currentCount >= 25) {
      alert('Node allocation limit reached for this account.');
      return;
    }

    setLoading(true);
    console.log('Initiating server provision for user:', auth.currentUser?.uid);
    try {
      const id = await serverService.createInstance(
        name, 
        mode === 'cloud' ? cores : 8, 
        mode === 'cloud' ? ram : 16, 
        120, 
        version,
        mode
      );
      if (!id) throw new Error('Provisioning failed: Node Cluster Refused Connection');
      setName('');
      onClose();
    } catch (e: any) {
      console.error('Provisioning failure:', e);
      let errorMsg = 'Node assignment failed. Data center capacity reached or network timeout.';
      try {
        const parsed = JSON.parse(e.message);
        if (parsed.error) errorMsg = `Infrastructure Error: ${parsed.error}`;
      } catch {
        if (e.message) errorMsg = e.message;
      }
      alert(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const coreOptions = [2, 4, 8, 16, 24, 32, 48, 64, 128];
  const ramOptions = [4, 8, 16, 32, 64, 128, 256];
  const versions = [
    '1.20.4', '1.20.1', 
    '1.19.4', '1.18.2', 
    '1.17.1', '1.16.5', 
    '1.12.2', '1.8.9',
    'Custom (Upload JAR)'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden p-8 shadow-2xl"
      >
        <h2 className="text-xl font-semibold text-white mb-6 tracking-tight flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Plus className="w-6 h-6 text-white" />
          </div>
          Initialize New Cluster
        </h2>
        
        <form onSubmit={create} className="space-y-5">
          <div className="flex gap-2 p-1 bg-slate-800 rounded-xl">
            <button 
              type="button"
              onClick={() => setMode('cloud')}
              className={cn(
                "flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all",
                mode === 'cloud' ? "bg-blue-600 text-white shadow-md" : "text-slate-500 hover:text-slate-300"
              )}
            >
              Cloud Hosted
            </button>
            <button 
              type="button"
              onClick={() => setMode('local')}
              className={cn(
                "flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all",
                mode === 'local' ? "bg-emerald-600 text-white shadow-md" : "text-slate-500 hover:text-slate-300"
              )}
            >
              Quantum Bridge (PC)
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Cluster Display Name</label>
              <input 
                type="text" 
                placeholder="e.g. survival-test-01"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white font-sans text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500/50 transition-all font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Game Version</label>
              <select 
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white font-sans text-sm focus:outline-none focus:border-blue-500 transition-all appearance-none cursor-pointer"
              >
                {versions.map(v => <option key={v} value={v}>Paper {v}</option>)}
              </select>
            </div>

            {mode === 'cloud' && (
              <>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Assign Cores</label>
                  <select 
                    value={cores}
                    onChange={(e) => setCores(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl p-3 text-white font-sans text-sm focus:outline-none focus:border-blue-500 transition-all appearance-none cursor-pointer"
                  >
                    {coreOptions.map(c => <option key={c} value={c}>{c} vCPUs</option>)}
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">RAM Allocation</label>
                  <div className="flex flex-wrap gap-2">
                    {ramOptions.map(r => (
                      <button
                        key={r}
                        type="button"
                        onClick={() => setRam(r)}
                        className={cn(
                          "px-4 py-2 rounded-lg text-xs font-bold border transition-all",
                          ram === r ? "bg-blue-600 border-blue-500 text-white" : "bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-500"
                        )}
                      >
                        {r}GB
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>

          <div className="flex items-center justify-between p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl mb-2">
             <div>
               <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Resource Allocation Pool</div>
               <div className="text-[9px] text-blue-400 font-bold uppercase mt-0.5">HIGH-PERFORMANCE COMPUTE CLUSTER (EU-CENTRAL)</div>
             </div>
             <div className="text-xs font-mono font-bold text-blue-400">{currentCount} / 25 Nodes</div>
          </div>

          <div className="pt-2 flex gap-3">
             <Button type="button" variant="ghost" className="flex-1" onClick={onClose} disabled={loading}>Cancel</Button>
             <Button type="submit" className="flex-1" disabled={loading}>
               {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Launch Cluster'}
             </Button>
          </div>
        </form>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = React.useState<User | null>(null);
  const [initializing, setInitializing] = React.useState(true);
  const [instances, setInstances] = React.useState<Instance[]>([]);
  const [activeLogId, setActiveLogId] = React.useState<string | null>(null);
  const [pluginInstance, setPluginInstance] = React.useState<Instance | null>(null);
  const [isProvisioning, setIsProvisioning] = React.useState(false);

  React.useEffect(() => {
    return onAuthStateChanged(auth, (u) => {
      setUser(u);
      setInitializing(false);
    });
  }, []);

  React.useEffect(() => {
    if (user) {
      const unsub = serverService.getInstances(user.uid, setInstances);
      return () => unsub();
    }
  }, [user]);

  const [isSigningIn, setIsSigningIn] = React.useState(false);

  const handleSignIn = async () => {
    if (isSigningIn) return;
    setIsSigningIn(true);
    try {
      await signIn();
    } catch (e: any) {
      if (e.code !== 'auth/popup-closed-by-user' && e.code !== 'auth/cancelled-popup-request') {
        console.error('Sign in error', e);
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  if (initializing) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden">
        {/* Background Grids */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:40px_40px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center z-10"
        >
          <div className="inline-flex items-center space-x-3 mb-8">
            <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center font-bold text-2xl text-white shadow-[0_0_30px_rgba(37,99,235,0.4)]">Q</div>
            <span className="text-3xl font-bold tracking-tight text-white">QuantumCloud</span>
          </div>
          
          <h1 className="text-5xl font-extrabold text-white mb-6 tracking-tight leading-tight max-w-xl mx-auto uppercase">
            Enterprise <span className="text-blue-500">Infrastructure</span>.
          </h1>
          <p className="text-slate-500 font-sans text-lg mb-12 max-w-md mx-auto leading-relaxed">
            High-performance compute nodes for mission-critical deployments.
            <span className="block mt-2 text-blue-400 font-bold text-sm">PROVISIONED IN GERMANY (FRA) • 100% UPTIME SLA</span>
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" onClick={handleSignIn} className="px-12 py-4 text-lg">
              Launch Free Server
            </Button>
            <a 
              href="https://quantum-mc.hosting" 
              onClick={(e) => e.preventDefault()}
              className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors text-sm font-medium border border-slate-800 px-6 py-4 rounded-xl"
            >
              <Globe className="w-4 h-4" />
              Official Website
            </a>
          </div>

          <div className="mt-12 flex items-center justify-center space-x-8 opacity-40">
             <div className="flex flex-col items-center">
               <span className="text-white font-mono text-xl">10ms</span>
               <span className="text-[10px] uppercase font-bold text-slate-500">Latancy</span>
             </div>
             <div className="w-px h-8 bg-slate-800" />
             <div className="flex flex-col items-center">
               <span className="text-white font-mono text-xl">99.99%</span>
               <span className="text-[10px] uppercase font-bold text-slate-500">Uptime</span>
             </div>
             <div className="w-px h-8 bg-slate-800" />
             <div className="flex flex-col items-center">
               <span className="text-white font-mono text-xl">TLS 1.3</span>
               <span className="text-[10px] uppercase font-bold text-slate-500">Security</span>
             </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-300 font-sans selection:bg-blue-600 selection:text-white">
      {/* Sidebar Layout */}
      <div className="flex h-screen overflow-hidden">
        {/* Sidebar */}
        <aside className="w-68 bg-slate-900/50 border-r border-slate-800 flex flex-col p-6 shrink-0 transition-all">
          <div className="flex items-center gap-3 mb-10 px-2 group cursor-pointer">
            <div className="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-white shadow-lg shadow-blue-500/20 group-hover:scale-110 transition-transform">
              <Cloud className="w-5 h-5" />
            </div>
            <span className="font-bold text-white tracking-tight text-lg">QuantumCloud</span>
          </div>

          <nav className="flex-1 space-y-1">
            {[
              { id: 'dash', name: 'Dashboard', icon: LayoutDashboard, active: true },
              { id: 'inst', name: 'Compute Nodes', icon: Server },
              { id: 'logs', name: 'Terminal Logs', icon: Terminal },
              { id: 'sec', name: 'Firewall', icon: Shield },
              { id: 'api', name: 'API Settings', icon: Activity },
            ].map((item) => (
              <button
                key={item.id}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 group",
                  item.active ? "bg-slate-800 text-white shadow-sm" : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                )}
              >
                <item.icon className={cn("w-4 h-4 transition-transform group-hover:scale-110", item.active ? "text-blue-400" : "text-slate-500")} />
                {item.name}
              </button>
            ))}
          </nav>

          <div className="pt-6 mt-6 border-t border-slate-800 space-y-6">
            {/* Telegram Button */}
            <a 
              href="https://t.me/tratrarar" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 text-blue-400 hover:text-blue-300 hover:bg-black/40 border border-blue-500/20 group"
            >
              <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Send className="w-4 h-4" />
              </div>
              <span className="font-bold tracking-tight">Our Telegram</span>
            </a>

            {/* Quota widget from design */}
            <div className="bg-blue-600/5 border border-blue-500/10 rounded-2xl p-4">
              <p className="text-[10px] font-bold text-blue-400 mb-2 uppercase tracking-widest">Resource Usage</p>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div className="bg-blue-500 h-1.5 rounded-full w-[45%] shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
              </div>
              <div className="flex justify-between items-center mt-3 font-mono text-[9px] text-slate-500">
                <span>650 / 2,000 GB</span>
                <span className="text-blue-400 font-bold">LITE PLAN</span>
              </div>
            </div>

            <div className="flex items-center gap-3 px-2">
              <img src={user.photoURL || ''} className="w-9 h-9 rounded-xl border border-slate-700 shadow-lg" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-white truncate tracking-tight">{user.displayName}</p>
                <p className="text-[10px] text-zinc-500 truncate mt-0.5">{user.email}</p>
              </div>
              <button 
                onClick={logout}
                className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-red-400 transition-colors"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto flex flex-col relative">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(37,99,235,0.05),transparent_50%)] pointer-events-none" />
          
          {/* Header */}
          <header className="sticky top-0 z-40 bg-slate-950/70 backdrop-blur-xl border-b border-slate-800 px-8 py-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-semibold text-white tracking-tight uppercase">Node <span className="text-blue-400">Inventory</span></h1>
              <p className="text-sm text-slate-500 mt-1 uppercase tracking-wider text-[10px] font-bold">RESOURCE MANAGEMENT • FRANKFURT CLUSTER 01</p>
            </div>
            <div className="flex gap-4">
              <a 
                href="https://t.me/tratrarar" 
                target="_blank" 
                rel="noopener noreferrer"
                className="hidden md:flex items-center gap-2 px-4 py-2 bg-blue-500/10 text-blue-400 rounded-xl text-xs font-bold border border-blue-500/20 hover:bg-blue-500/20 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                COMMUNITY TG
              </a>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input 
                  type="text" 
                  placeholder="Filter nodes..." 
                  className="bg-slate-900 border border-slate-800 rounded-xl pl-11 pr-5 py-2.5 text-sm focus:outline-none focus:border-blue-500 w-64 transition-all placeholder:text-slate-700"
                />
              </div>
              <Button size="md" onClick={() => setIsProvisioning(true)} className="px-6">
                <Plus className="w-4 h-4" />
                New Server
              </Button>
            </div>
          </header>

          <div className="p-8 space-y-8 flex-1">
            {/* Network Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between group overflow-hidden relative">
                <div className="absolute top-0 right-0 p-2 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Activity className="w-16 h-16 text-blue-400" />
                </div>
                <div className="flex items-center gap-4 relative z-10">
                  <div className="w-3 h-3 bg-emerald-500 rounded-full shadow-[0_0_12px_rgba(16,185,129,0.5)]" />
                  <div>
                    <p className="text-xs font-bold text-white uppercase tracking-widest">Global Compute Hub (EU-FRA)</p>
                    <p className="text-[10px] text-slate-500">Tier-3 Data Center • Direct Fiber Uplink Active</p>
                  </div>
                </div>
                <div className="text-emerald-400 text-[10px] font-bold px-3 py-1 bg-emerald-500/10 rounded-full border border-emerald-500/20">OPERATIONAL</div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 flex items-center justify-between group overflow-hidden relative">
                <div className="absolute top-0 right-0 p-2 opacity-5">
                  <ShieldCheck className="w-16 h-16 text-blue-400" />
                </div>
                <div className="flex items-center gap-4 relative z-10">
                  <div className="w-3 h-3 bg-blue-500 rounded-full shadow-[0_0_12px_rgba(59,130,246,0.5)]" />
                  <div>
                    <p className="text-xs font-bold text-white uppercase tracking-widest">Global IP Shield</p>
                    <p className="text-[10px] text-slate-500">DDoS Mitigation Engine • Anycast Routing enabled</p>
                  </div>
                </div>
                <div className="text-blue-400 text-[10px] font-bold px-3 py-1 bg-blue-500/10 rounded-full border border-blue-500/20">READY</div>
              </div>
            </div>

            {/* Metrics Bar */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { label: 'Network Load', val: '0.4', unit: 'GBPS', icon: Activity },
                { label: 'Uptime Score', val: '100', unit: '%', icon: ShieldCheck },
                { label: 'Available Pool', val: '12.4', unit: 'TB', icon: HardDrive },
                { label: 'Latency', val: '8.4', unit: 'MS', icon: Zap },
              ].map((item, idx) => (
                <div key={idx} className="bg-slate-900/40 border border-slate-800 p-6 rounded-2xl group hover:border-blue-500/30 transition-all">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-2.5 rounded-xl bg-slate-800 text-blue-400 group-hover:bg-blue-500 group-hover:text-white transition-all shadow-lg">
                      <item.icon className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{item.label}</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-mono font-bold text-white">{item.val}</span>
                    <span className="text-sm font-semibold text-slate-600 uppercase">{item.unit}</span>
                  </div>
                  <div className="mt-4 h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '85%' }}
                      className="h-full bg-blue-500/40 rounded-full"
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Instance Table */}
            <Card title="ACTIVE DEPLOYMENTS" icon={Server}>
              <div className="overflow-x-auto -mx-2">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-slate-500 border-b border-slate-800">
                      <th className="text-left font-semibold pb-4 pt-1 px-4">Server Name</th>
                      <th className="text-left font-semibold pb-4 pt-1 px-4">Status</th>
                      <th className="text-left font-semibold pb-4 pt-1 px-4">Direct Connection (IP:Port)</th>
                      <th className="text-left font-semibold pb-4 pt-1 px-4">Configuration</th>
                      <th className="text-right font-semibold pb-4 pt-1 px-4">Console</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50">
                    <AnimatePresence initial={false}>
                      {instances.map((instance) => (
                        <motion.tr 
                          key={instance.id}
                          layout
                          className="group hover:bg-slate-800/30 transition-colors"
                        >
                          <td className="py-5 px-4">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-blue-500 font-bold shadow-sm group-hover:bg-blue-500/10 transition-colors">
                                <Server className="w-5 h-5" />
                              </div>
                              <div>
                                <div className="text-white font-semibold tracking-tight flex items-center gap-2 uppercase">
                                  {instance.name}
                                  {instance.type === 'local' && (
                                    <span className="text-[8px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/20">HYBRID</span>
                                  )}
                                </div>
                                <div className="text-[10px] text-slate-600 font-mono mt-0.5">{instance.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="py-5 px-4">
                            <Badge status={instance.status} />
                          </td>
                          <td className="py-5 px-4 font-mono text-slate-400 text-xs tracking-tight">
                            {instance.ip ? (
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-1 bg-slate-800 rounded-lg text-blue-400 font-bold">{instance.ip}:{instance.port || 25565}</span>
                                <Button size="sm" variant="ghost" className="p-1 h-auto" onClick={() => {
                                  navigator.clipboard.writeText(`${instance.ip}:${instance.port || 25565}`);
                                }}>Copy</Button>
                              </div>
                            ) : (
                              <span className="text-slate-700 italic">ALLOCATING IP...</span>
                            )}
                          </td>
                          <td className="py-5 px-4">
                             <div className="flex flex-col gap-1">
                                <div className="flex gap-4 text-slate-500 font-mono text-[10px] uppercase">
                                   <span className="flex items-center gap-1.5"><Zap className="w-3.5 h-3.5 text-blue-500" />{instance.ram}GB RAM</span>
                                   <span className="flex items-center gap-1.5"><Cpu className="w-3.5 h-3.5" />{instance.cpu} CORES</span>
                                </div>
                                <div className="text-[9px] text-slate-600 font-bold uppercase tracking-tighter">
                                   Paper {instance.version || '1.20.4'}
                                </div>
                             </div>
                          </td>
                          <td className="py-5 px-4 text-right">
                             <div className="flex justify-end gap-2">
                               <Button size="sm" variant="secondary" title="Direct File Deployment" onClick={async () => {
                                 const folderName = prompt('Enter destination directory:');
                                 if (!folderName) return;
                                 await serverService.addLog(instance.id, `Deployment started: Syncing assets to /clusters/${folderName}...`, 'info');
                                 await serverService.addLog(instance.id, `Successfully deployed package to ${folderName}/. Cluster manifest updated.`, 'info');
                               }}>
                                 <Cloud className="w-3.5 h-3.5" />
                               </Button>
                               <Button size="sm" variant="secondary" title="Manage Plugins" onClick={() => setPluginInstance(instance)}>
                                 <Settings className="w-3.5 h-3.5" />
                               </Button>
                               <Button size="sm" variant="secondary" title="View Console" onClick={() => setActiveLogId(instance.id)}>
                                 <Terminal className="w-3.5 h-3.5" />
                               </Button>
                               
                               {instance.status === 'running' ? (
                                 <Button size="sm" variant="secondary" title="Power Off" onClick={() => serverService.stopServer(instance.id)}>
                                   <Power className="w-3.5 h-3.5 text-red-500" />
                                 </Button>
                               ) : (
                                 <Button size="sm" variant="secondary" title="Power On" onClick={() => serverService.startServer(instance.id)} disabled={instance.status !== 'stopped'}>
                                   <Power className="w-3.5 h-3.5 text-emerald-500" />
                                 </Button>
                               )}
                               
                               <Button size="sm" variant="danger" title="Terminate" onClick={() => {
                                 if (confirm('Are you sure you want to delete this cluster? This action is irreversible.')) {
                                   serverService.deleteServer(instance.id);
                                 }
                               }}>
                                 <Trash2 className="w-3.5 h-3.5" />
                               </Button>
                             </div>
                          </td>
                        </motion.tr>
                      ))}
                    </AnimatePresence>
                    {instances.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-20 text-center text-slate-600 italic">
                          No active clusters found. Launch an instance to begin provisioning.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Bottom Info Panels from Design */}
            <div className="grid grid-cols-12 gap-8 pb-8">
               <div className="col-span-12 lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-6">
                 <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-lg font-semibold text-white tracking-tight">Active Traffic Flow</h3>
                      <p className="text-xs text-slate-500 mt-1">Real-time aggregate data throughput across all nodes</p>
                    </div>
                    <div className="flex items-center gap-1.5 bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full">
                       <Activity className="w-3.5 h-3.5 text-blue-400" />
                       <span className="text-[10px] font-bold text-blue-400 uppercase tracking-widest">In Transit</span>
                    </div>
                 </div>
                 <div className="h-24 flex items-end gap-1.5 px-2">
                    {[45, 65, 30, 85, 40, 95, 20, 75, 55, 80, 45, 100, 60, 90, 35].map((h, i) => (
                      <motion.div 
                        key={i}
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        className="flex-1 bg-blue-600/20 border-t-2 border-blue-600 rounded-t-sm"
                      />
                    ))}
                 </div>
               </div>

               <div className="col-span-12 lg:col-span-4 bg-slate-900/50 border border-dashed border-slate-700 p-8 rounded-2xl text-center group cursor-pointer hover:border-blue-500 hover:bg-blue-600/5 transition-all">
                  <div className="w-14 h-14 bg-slate-800 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-blue-600/20 group-hover:scale-110 transition-all">
                    <Cloud className="w-7 h-7 text-slate-500 group-hover:text-blue-400" />
                  </div>
                  <h4 className="text-lg font-semibold text-white tracking-tight">Snapshot Archives</h4>
                  <p className="text-sm text-slate-500 mt-2 leading-relaxed">Backup your cluster state or migrate Dockerfiles for instant deployment.</p>
                  <div className="mt-6 flex items-center justify-center gap-2 text-[11px] font-bold text-blue-500 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                    Access Library <ChevronRight className="w-3.5 h-3.5" />
                  </div>
               </div>
            </div>
          </div>

          <footer className="mt-auto h-14 border-t border-slate-800 bg-slate-900/50 px-8 flex items-center justify-between text-[11px] font-mono text-slate-500 uppercase tracking-wider backdrop-blur-md">
            <div className="flex space-x-8">
              <span className="flex items-center gap-2"><div className="w-1 h-1 bg-blue-500 rounded-full" /> Powered by QuantumCloud Bare-Metal</span>
              <span className="hidden md:inline">Platform: 100% Dedicated Hardware</span>
              <span className="hidden md:inline">Provider: s02538915 Infrastructure</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.6)]"></div>
              <span className="text-emerald-400 font-bold">Encrypted Connection</span>
            </div>
          </footer>
        </main>
      </div>

      {/* Modals */}
      <AnimatePresence>
        {activeLogId && (
          <LogPanel 
            instanceId={activeLogId} 
            onClose={() => setActiveLogId(null)} 
          />
        )}
      </AnimatePresence>

      <ProvisionModal 
        isOpen={isProvisioning} 
        onClose={() => setIsProvisioning(false)} 
        currentCount={instances.length}
      />

      <AnimatePresence>
        {pluginInstance && (
          <PluginModal
            isOpen={true}
            instance={pluginInstance}
            onClose={() => setPluginInstance(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

